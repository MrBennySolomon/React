import Increment from './Increment';
function App() {
  
  return (
    <div className="App">
      <Increment counter='0'/>
    </div>
  );
}

export default App;
