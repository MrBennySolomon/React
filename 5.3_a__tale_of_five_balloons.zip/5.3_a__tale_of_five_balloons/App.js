import Mother from './Mother';

function App() {
  
  return (
    <div className="App">
      <Mother/>
    </div>
  );
}

export default App;
