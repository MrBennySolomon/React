
import React from 'react'

const Home = () => {

  return (
    <>
      <h1>My Home Page</h1>
    </>
    
  )
}

export default Home